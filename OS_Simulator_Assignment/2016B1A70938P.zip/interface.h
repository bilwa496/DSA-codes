/************************************************
*Name:Indraneel Ghosh							*    										  
*ID:2016B1A70938P							  	*
*												*
*												*
*************************************************/

#include <stdio.h>

//define functions and structures for interface
extern void menu();
//header 
